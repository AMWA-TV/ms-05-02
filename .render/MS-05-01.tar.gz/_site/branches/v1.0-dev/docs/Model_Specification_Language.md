# Model specification language

[←Components ](Components.html) · [ Index↑ ](..) · [Control Model→](Control_Model.html)

Normative specifications of NCA control and Device models is expressed in the \[YANG 1.1\] modeling language defined by \[RFC 7950\], with the YANG complex-type extensions defined by \[RFC 6095\]. As well, NCA adds a set of custom YANG extensions that are defined in the control model base text.

[←Components ](Components.html) · [ Index↑ ](..) · [Control Model→](Control_Model.html)
