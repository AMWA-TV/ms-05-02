# Changelog
This document provides an overview of changes between released versions of this specification.

## Release v1.0
*   Initial release
